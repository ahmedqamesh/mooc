


 =============================================================================

 Copyright (c) 2017 SAS Institute Inc.                                       
 Cary, N.C. USA 27513-8000                                                    
 all rights reserved                                                          
                                                                              
 THE INFORMATION CONTAINED IN THIS DISTRIBUTION IS PROVIDED BY THE INSTITUTE      
 "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING 
 BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 A PARTICULAR PURPOSE.  RECIPIENTS ACKNOWLEDGE AND AGREE THAT THE INSTITUTE   
 SHALL NOT BE LIABLE WHATSOEVER FOR ANY DAMAGES ARISING OUT OF THEIR USE OF   
 THIS INFORMATION.                                                            
                                                                            
